import React from 'react';
import Header from '../components/Header';
import HeroSlider from '../components/HeroSlider';
import StatsSection from '../components/StatsSection';
import ProgramsSection from '../components/ProgramsSection';
import EventsSection from '../components/EventsSection';
import MembersSection from '../components/MembersSection';
import JoinSection from '../components/JoinSection';
import DonationSection from '../components/DonationSection';
import Footer from '../components/Footer';

const HomePage = () => {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <HeroSlider />
      <StatsSection />
      <ProgramsSection />
      <EventsSection />
      <MembersSection />
      <JoinSection />
      <DonationSection />
      <Footer />
    </div>
  );
};

export default HomePage;