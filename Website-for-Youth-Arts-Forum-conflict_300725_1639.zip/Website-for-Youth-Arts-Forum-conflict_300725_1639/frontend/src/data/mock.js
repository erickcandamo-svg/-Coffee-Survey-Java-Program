// Mock data for Youth Arts Forum
export const heroSlides = [
  {
    id: 1,
    title: "Uniting Youth Through Arts",
    subtitle: "Empowering young artists and performers worldwide since 1990",
    description: "Youth Arts Forum provides talented young artists with platforms to express creativity through visual arts and music.",
    bgColor: "#1f47e6",
    textColor: "#b7fbff",
    cta: "Join Our Community",
    image: "https://customer-assets.emergentagent.com/job_artsforum/artifacts/wynpsnwg_sor%20ridgefield.jpeg"
  },
  {
    id: 2,
    title: "Rock for a Cure",
    subtitle: "Kids Helping Kids Concert Series",
    description: "Supporting young performers across NYC, New Jersey, Vermont, and 32 Simon Malls nationwide.",
    bgColor: "#d987ff",
    textColor: "#151515",
    cta: "View Events",
    image: "https://customer-assets.emergentagent.com/job_artsforum/artifacts/e77n5vxe_dial%20tone.jpeg"
  },
  {
    id: 3,
    title: "Visual Arts Program",
    subtitle: "Gallery Exhibitions & Art Supplies",
    description: "Showcasing young talent in renowned spaces like NOHO Art Gallery and Rivington Street Gallery.",
    bgColor: "#ff84e4",
    textColor: "#151515",
    cta: "Explore Gallery",
    image: "https://customer-assets.emergentagent.com/job_artsforum/artifacts/vuiqtxhf_double%20a.jpeg"
  }
];

export const featuredEvents = [
  {
    id: 1,
    title: "The Bitter End NYC",
    date: "October 5th, 2024",
    time: "1:00 PM",
    venue: "The Bitter End",
    location: "NYC",
    price: "$10.00",
    description: "Chillin to some amazing music in the Fall",
    artists: ["Double A", "SOR Farmingdale", "Sor Sayville", "Adolescence", "Glenn Strange", "Fallen Anthem"],
    flyer: "https://customer-assets.emergentagent.com/job_artsforum/artifacts/4qa5rey7_Music-flyer105.png",
    category: "performing-arts"
  },
  {
    id: 2,
    title: "Battle of the School of Rock",
    date: "March 25th, 2023",
    time: "1:00 PM - 5:30 PM",
    venue: "The Iconic Bitter End",
    location: "NYC",
    price: "$10.00",
    description: "Concert to benefit art & music in underfunded schools",
    schools: ["SOR Ridgefield CT", "SOR New Canaan CT", "SOR Montclair NJ"],
    flyer: "https://customer-assets.emergentagent.com/job_artsforum/artifacts/uh59zws6_march%2025th%20bitter%20end.png",
    category: "performing-arts"
  }
];

export const memberShowcase = [
  {
    id: 1,
    name: "YAF Rock Band Members",
    category: "Performing Arts",
    description: "Young musicians showcasing their talent at YAF events",
    image: "https://customer-assets.emergentagent.com/job_artsforum/artifacts/e77n5vxe_dial%20tone.jpeg",
    tags: ["Music", "Performance", "Youth"]
  },
  {
    id: 2,
    name: "YAF Community",
    category: "Visual & Performing Arts",
    description: "Our diverse community of young artists and performers",
    image: "https://customer-assets.emergentagent.com/job_artsforum/artifacts/wynpsnwg_sor%20ridgefield.jpeg",
    tags: ["Community", "Arts", "Youth"]
  },
  {
    id: 3,
    name: "Double A",
    category: "Visual Arts",
    description: "Emerging artist showcasing creative visual expression",
    image: "https://customer-assets.emergentagent.com/job_artsforum/artifacts/vuiqtxhf_double%20a.jpeg",
    tags: ["Visual Arts", "Photography", "Creative"]
  }
];

export const programs = [
  {
    id: 1,
    title: "Performing Arts",
    description: "Rock for a Cure concerts across NYC, New Jersey, Vermont, and 32 Simon Malls nationwide. We cover venue costs, marketing, and production.",
    venues: ["The Studio at Webster Hall", "Arlene's Grocery", "The National Underground", "Slate", "Beekman Beer Garden", "The Bitter End", "The Stone Pony"],
    color: "mid-blue",
    icon: "Music"
  },
  {
    id: 2,
    title: "Visual Arts",
    description: "Art supply distribution, professional framing, and gallery exhibitions in renowned spaces like NOHO Art Gallery and Rivington Street Gallery.",
    venues: ["NOHO Art Gallery", "Rivington Street Gallery", "Parasol Project", "YouthArtsForum.org Online Gallery"],
    color: "mid-purple",
    icon: "Palette"
  }
];

export const socialLinks = [
  {
    name: "Instagram",
    url: "https://www.instagram.com/youthartsforum/",
    icon: "Instagram"
  },
  {
    name: "Facebook", 
    url: "https://www.facebook.com/youthartsforum.org/",
    icon: "Facebook"
  },
  {
    name: "YouTube",
    url: "https://www.youtube.com/@barrysalottolo3548",
    icon: "Youtube"
  }
];

export const contactInfo = {
  founder: "Barry Salottolo",
  website: "http://youthartsforum.org",
  email: "info@youthartsforum.org",
  address: "106 William Street, Norwalk, CT 06851",
  phone: "(914) 310-2930",
  donationLink: "https://www.paypal.com/donate/?hosted_button_id=44ZH6XWEQHMW8"
};

export const stats = [
  { number: "30+", label: "Years Supporting Youth" },
  { number: "32", label: "Simon Mall Venues" },
  { number: "1000+", label: "Young Artists Supported" },
  { number: "501(c)(3)", label: "Registered Charity" }
];