import React from 'react';
import { Instagram, Facebook, Youtube, Mail, Phone, MapPin } from 'lucide-react';
import { socialLinks, contactInfo } from '../data/mock';

const Footer = () => {
  const iconMap = {
    Instagram: Instagram,
    Facebook: Facebook,  
    Youtube: Youtube
  };

  return (
    <footer className="bg-black text-white py-16">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <h3 className="font-display text-2xl font-bold uppercase text-light-pink mb-4">
              Youth Arts Forum
            </h3>
            <p className="text-white/80 max-w-md">
              "Uniting the Youth of the World Through the Arts" - Supporting underfunded school 
              art and music programs since 1990.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social) => {
                const IconComponent = iconMap[social.icon];
                return (
                  <a
                    key={social.name}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-light-pink hover:text-black transition-all duration-300"
                  >
                    <IconComponent size={18} />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-mono text-sm uppercase tracking-wider text-white/60 mb-4">
              Quick Links
            </h4>
            <div className="space-y-2">
              {[
                { name: 'About', href: '#about' },
                { name: 'Programs', href: '#programs' },
                { name: 'Events', href: '#events' },
                { name: 'Members', href: '#members' },
                { name: 'Join YAF', href: '#join' },
                { name: 'Donate', href: '#donate' }
              ].map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="block text-white/80 hover:text-light-pink transition-colors duration-200"
                >
                  {link.name}
                </a>
              ))}
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-mono text-sm uppercase tracking-wider text-white/60 mb-4">
              Contact
            </h4>
            <div className="space-y-3">
              <div className="flex items-start gap-3 text-white/80">
                <Mail size={16} className="mt-1 flex-shrink-0" />
                <div>
                  <div className="font-bold text-white mb-1">Founder</div>
                  <div className="text-sm">{contactInfo.founder}</div>
                </div>
              </div>
              
              <div className="flex items-start gap-3 text-white/80">
                <Phone size={16} className="mt-1 flex-shrink-0" />
                <div className="text-sm">{contactInfo.phone}</div>
              </div>
              
              <div className="flex items-start gap-3 text-white/80">
                <MapPin size={16} className="mt-1 flex-shrink-0" />
                <div className="text-sm">{contactInfo.address}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-white/60">
              © 2024 Youth Arts Forum. All rights reserved. 501(c)(3) Non-Profit Organization.
            </div>
            <div className="text-sm">
              <a 
                href={contactInfo.website}
                target="_blank"
                rel="noopener noreferrer"
                className="text-light-pink hover:text-white transition-colors"
              >
                {contactInfo.website}
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;