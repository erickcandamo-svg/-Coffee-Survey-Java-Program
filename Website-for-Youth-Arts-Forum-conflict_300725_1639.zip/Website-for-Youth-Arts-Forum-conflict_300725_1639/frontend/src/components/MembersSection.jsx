import React from 'react';
import { useMembers } from '../hooks/useApi';
import { LoadingSection } from './LoadingSpinner';
import { ErrorMessage } from './ErrorBoundary';

const MembersSection = () => {
  const { data: memberShowcase, loading, error, refetch } = useMembers({ featured: true, limit: 6 });

  if (loading) {
    return (
      <section id="members" className="py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <LoadingSection message="Loading members..." />
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section id="members" className="py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <ErrorMessage error={error} onRetry={refetch} />
        </div>
      </section>
    );
  }

  return (
    <section id="members" className="py-24 bg-white">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-6xl font-bold uppercase text-black mb-6">
            Our Members
          </h2>
          <p className="text-xl text-dark-grey max-w-3xl mx-auto">
            Talented young artists and performers from around the world
          </p>
        </div>

        {memberShowcase && memberShowcase.length > 0 ? (
          <>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {memberShowcase.map((member) => (
                <div 
                  key={member.id} 
                  className="group relative overflow-hidden rounded-lg bg-grey hover:shadow-xl transition-all duration-300"
                >
                  {/* Member Image */}
                  <div className="aspect-square overflow-hidden">
                    <img
                      src={member.image_url}
                      alt={member.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      onError={(e) => {
                        e.target.src = 'https://via.placeholder.com/400x400/d987ff/000000?text=YAF+Member';
                      }}
                    />
                  </div>

                  {/* Member Info Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                      <div className="mb-3">
                        <span className="service-button bg-mid-pink text-black text-xs">
                          {member.art_category.replace('-', ' ')}
                        </span>
                      </div>
                      <h3 className="text-xl font-bold mb-2">
                        {member.name}
                      </h3>
                      {member.message && (
                        <p className="text-sm opacity-90 mb-4">
                          {member.message}
                        </p>
                      )}
                      <div className="flex flex-wrap gap-1">
                        <span className="text-xs bg-white/20 px-2 py-1 rounded-full">
                          Age {member.age}
                        </span>
                        {member.experience && (
                          <span className="text-xs bg-white/20 px-2 py-1 rounded-full">
                            {member.experience}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Static Member Info for Mobile */}
                  <div className="p-4 md:hidden">
                    <div className="mb-2">
                      <span className="service-button bg-mid-pink text-black text-xs">
                        {member.art_category.replace('-', ' ')}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-black mb-2">
                      {member.name}
                    </h3>
                    {member.message && (
                      <p className="text-sm text-dark-grey mb-3">
                        {member.message}
                      </p>
                    )}
                    <div className="flex flex-wrap gap-1">
                      <span className="text-xs bg-grey text-black px-2 py-1 rounded-full">
                        Age {member.age}
                      </span>
                      {member.experience && (
                        <span className="text-xs bg-grey text-black px-2 py-1 rounded-full">
                          {member.experience}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center mt-12">
              <button className="cta-button bg-mid-purple text-black hover:bg-mid-purple/80">
                View All Members
              </button>
            </div>
          </>
        ) : (
          <div className="text-center py-16">
            <p className="text-xl text-dark-grey">
              No featured members available at the moment.
            </p>
          </div>
        )}
      </div>
    </section>
  );
};

export default MembersSection;