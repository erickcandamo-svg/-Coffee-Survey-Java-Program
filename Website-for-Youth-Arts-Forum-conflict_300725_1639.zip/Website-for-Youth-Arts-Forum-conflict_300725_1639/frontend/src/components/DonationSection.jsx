import React from 'react';
import { Heart, CreditCard, Mail } from 'lucide-react';
import { contactInfo } from '../data/mock';

const DonationSection = () => {
  const donationImpacts = [
    {
      amount: "$25",
      impact: "Provides art supplies for one young artist"
    },
    {
      amount: "$50", 
      impact: "Covers venue costs for a local performance"
    },
    {
      amount: "$100",
      impact: "Supports travel expenses for touring artists"
    },
    {
      amount: "$250",
      impact: "Funds a complete gallery exhibition"
    }
  ];

  return (
    <section id="donate" className="py-24 bg-light-pink">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-6xl font-bold uppercase text-black mb-6">
            Support Young Artists
          </h2>
          <p className="text-xl text-dark-grey max-w-3xl mx-auto">
            Your donation helps fund concerts, artist sponsorships, exhibitions, production costs, 
            supplies, and all expenses needed to support young visual and performing artists.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Donation Impact */}
          <div>
            <h3 className="text-2xl font-bold text-black mb-8">
              Your Impact
            </h3>
            
            <div className="space-y-6 mb-8">
              {donationImpacts.map((item, index) => (
                <div key={index} className="flex items-center gap-4 p-4 bg-white rounded-lg">
                  <div className="bg-mid-purple text-black font-bold text-lg px-4 py-2 rounded-lg min-w-[80px] text-center">
                    {item.amount}
                  </div>
                  <p className="text-dark-grey">
                    {item.impact}
                  </p>
                </div>
              ))}
            </div>

            <div className="bg-white p-6 rounded-lg">
              <h4 className="text-lg font-bold text-black mb-3 flex items-center gap-2">
                <Heart size={20} className="text-mid-pink" />
                Why We Need Your Support
              </h4>
              <p className="text-dark-grey text-sm leading-relaxed">
                YAF was created to address the decline of formal school art and music programs. 
                Your support helps us provide essential supplies and support to underfunded programs.
              </p>
            </div>
          </div>

          {/* Donation Methods */}
          <div className="space-y-8">
            {/* Online Donation */}
            <div className="bg-white rounded-lg p-8">
              <div className="flex items-center gap-3 mb-6">
                <CreditCard size={24} className="text-mid-blue" />
                <h3 className="text-2xl font-bold text-black">
                  Donate Online
                </h3>
              </div>
              
              <p className="text-dark-grey mb-6 leading-relaxed">
                Make a secure donation through PayPal. All donations are tax-deductible 
                and go directly to supporting young artists.
              </p>
              
              <a 
                href={contactInfo.donationLink}
                target="_blank"
                rel="noopener noreferrer"
                className="cta-button bg-mid-blue text-white hover:bg-mid-blue/80 w-full inline-block text-center"
              >
                Donate Now via PayPal
              </a>
            </div>

            {/* Mail Donation */}
            <div className="bg-white rounded-lg p-8">
              <div className="flex items-center gap-3 mb-6">
                <Mail size={24} className="text-mid-purple" />
                <h3 className="text-2xl font-bold text-black">
                  Donate by Mail
                </h3>
              </div>
              
              <p className="text-dark-grey mb-4 leading-relaxed">
                Send your tax-deductible contribution to:
              </p>
              
              <div className="bg-grey/30 p-4 rounded-lg font-mono text-sm">
                <div className="font-bold text-black mb-2">Youth Arts Forum</div>
                <div className="text-dark-grey">
                  {contactInfo.address}
                </div>
              </div>
            </div>

            {/* Partnership */}
            <div className="bg-mid-yellow rounded-lg p-8">
              <h3 className="text-2xl font-bold text-black mb-4">
                Corporate Partnership
              </h3>
              <p className="text-black/80 mb-4 leading-relaxed">
                We've partnered with major retailers like Amazon and Queensboro Clothing 
                where a percentage of every sale helps support our mission.
              </p>
              <button className="cta-button bg-black text-white hover:bg-gray-800">
                Learn About Partnerships
              </button>
            </div>
          </div>
        </div>

        {/* 501(c)(3) Notice */}
        <div className="text-center mt-16 p-6 bg-white/50 rounded-lg">
          <p className="text-sm text-dark-grey">
            Youth Arts Forum is a registered 501(c)(3) non-profit organization. 
            All donations are tax-deductible to the full extent allowed by law.
          </p>
        </div>
      </div>
    </section>
  );
};

export default DonationSection;