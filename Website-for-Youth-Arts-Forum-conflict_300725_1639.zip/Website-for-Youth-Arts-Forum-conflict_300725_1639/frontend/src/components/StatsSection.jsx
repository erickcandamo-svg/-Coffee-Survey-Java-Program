import React from 'react';
import { useSiteSettings } from '../hooks/useApi';
import { LoadingSection } from './LoadingSpinner';

const StatsSection = () => {
  const { data: settings, loading } = useSiteSettings();

  // Fallback stats if API fails
  const fallbackStats = [
    { number: "30+", label: "Years Supporting Youth" },
    { number: "32", label: "Simon Mall Venues" },
    { number: "1000+", label: "Young Artists Supported" },
    { number: "501(c)(3)", label: "Registered Charity" }
  ];

  const stats = settings?.stats || fallbackStats;

  if (loading) {
    return (
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4 lg:px-8">
          <LoadingSection message="Loading statistics..." />
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-black mb-2">
                {stat.number}
              </div>
              <div className="text-sm md:text-base text-dark-grey uppercase font-mono tracking-wider">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsSection;