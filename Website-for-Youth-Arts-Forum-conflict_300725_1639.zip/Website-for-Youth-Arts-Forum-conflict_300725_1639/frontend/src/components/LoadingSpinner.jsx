import React from 'react';

const LoadingSpinner = ({ size = 'medium', className = '' }) => {
  const sizes = {
    small: 'w-4 h-4',
    medium: 'w-8 h-8', 
    large: 'w-12 h-12'
  };

  return (
    <div className={`inline-block animate-spin rounded-full border-2 border-current border-t-transparent ${sizes[size]} ${className}`}>
      <span className="sr-only">Loading...</span>
    </div>
  );
};

export const LoadingSection = ({ message = 'Loading...' }) => {
  return (
    <div className="flex flex-col items-center justify-center py-16 space-y-4">
      <LoadingSpinner size="large" className="text-mid-blue" />
      <p className="text-dark-grey">{message}</p>
    </div>
  );
};

export const LoadingOverlay = ({ message = 'Loading...' }) => {
  return (
    <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center space-y-4 z-50">
      <LoadingSpinner size="large" className="text-mid-blue" />
      <p className="text-dark-grey font-mono text-sm uppercase tracking-wider">{message}</p>
    </div>
  );
};

export default LoadingSpinner;