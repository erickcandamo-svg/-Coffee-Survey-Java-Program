import React, { useState } from 'react';
import { Users, Star, Globe } from 'lucide-react';
import { useFormSubmission } from '../hooks/useApi';
import { apiService } from '../services/api';
import LoadingSpinner from './LoadingSpinner';

const JoinSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    age: '',
    art_category: '',
    experience: '',
    message: ''
  });

  const { loading, error, success, submitForm, reset } = useFormSubmission();

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const submitData = {
        ...formData,
        age: parseInt(formData.age)
      };

      await submitForm(() => apiService.submitJoinForm(submitData));
      
      // Reset form on success
      setFormData({
        name: '',
        email: '',
        age: '',
        art_category: '',
        experience: '',
        message: ''
      });
      
      // Auto-reset success message after 5 seconds
      setTimeout(() => {
        reset();
      }, 5000);
      
    } catch (err) {
      console.error('Form submission error:', err);
    }
  };

  const benefits = [
    {
      icon: Users,
      title: "Global Community",
      description: "Connect with young artists worldwide"
    },
    {
      icon: Star,
      title: "Performance Opportunities", 
      description: "Showcase your talent at renowned venues"
    },
    {
      icon: Globe,
      title: "Professional Development",
      description: "Build your artistic portfolio and network"
    }
  ];

  return (
    <section id="join" className="py-24 bg-mid-blue">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-6xl font-bold uppercase text-white mb-6">
            Join YAF
          </h2>
          <p className="text-xl text-white/80 max-w-3xl mx-auto">
            All visual artists and musicians 18 years old and younger (or up to 25 as Ambassador Members) 
            from the U.S. and around the world are invited to join Youth Arts Forum.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Benefits */}
          <div className="space-y-8">
            <h3 className="text-2xl font-bold text-white mb-8">
              Why Join Youth Arts Forum?
            </h3>
            
            {benefits.map((benefit, index) => {
              const IconComponent = benefit.icon;
              return (
                <div key={index} className="flex items-start gap-4">
                  <div className="bg-white/20 p-3 rounded-lg flex-shrink-0">
                    <IconComponent size={24} className="text-white" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-white mb-2">
                      {benefit.title}
                    </h4>
                    <p className="text-white/80">
                      {benefit.description}
                    </p>
                  </div>
                </div>
              );
            })}

            <div className="bg-white/10 p-6 rounded-lg mt-8">
              <h4 className="text-lg font-bold text-white mb-3">
                Share Your Craft
              </h4>
              <p className="text-white/80 text-sm">
                Members can post videos, photos, blogs, and connect with other young creatives. 
                It's a powerful way to share your craft with a wider audience.
              </p>
            </div>
          </div>

          {/* Join Form */}
          <div className="bg-white rounded-lg p-8 relative">
            {loading && (
              <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center rounded-lg z-10">
                <div className="text-center">
                  <LoadingSpinner size="large" className="text-mid-blue mb-4" />
                  <p className="text-dark-grey">Submitting your application...</p>
                </div>
              </div>
            )}

            <h3 className="text-2xl font-bold text-black mb-6">
              Apply for Membership
            </h3>

            {success && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                <h4 className="font-bold text-green-800 mb-2">Application Submitted!</h4>
                <p className="text-green-700 text-sm">
                  Thank you for your interest in joining YAF. We'll review your application and contact you soon.
                </p>
              </div>
            )}

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                <h4 className="font-bold text-red-800 mb-2">Submission Error</h4>
                <p className="text-red-700 text-sm">
                  {error.response?.data?.detail || error.message || 'Unable to submit application. Please try again.'}
                </p>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-mono uppercase tracking-wider text-dark-grey mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  disabled={loading}
                  className="w-full px-4 py-3 border border-grey rounded-lg focus:ring-2 focus:ring-mid-blue focus:border-mid-blue transition-colors disabled:opacity-50"
                  placeholder="Your full name"
                />
              </div>

              <div>
                <label className="block text-sm font-mono uppercase tracking-wider text-dark-grey mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  disabled={loading}
                  className="w-full px-4 py-3 border border-grey rounded-lg focus:ring-2 focus:ring-mid-blue focus:border-mid-blue transition-colors disabled:opacity-50"
                  placeholder="your@email.com"
                />
              </div>

              <div>
                <label className="block text-sm font-mono uppercase tracking-wider text-dark-grey mb-2">
                  Age *
                </label>
                <input
                  type="number"
                  name="age"
                  value={formData.age}
                  onChange={handleInputChange}
                  required
                  min="1"
                  max="25"
                  disabled={loading}
                  className="w-full px-4 py-3 border border-grey rounded-lg focus:ring-2 focus:ring-mid-blue focus:border-mid-blue transition-colors disabled:opacity-50"
                  placeholder="Your age"
                />
              </div>

              <div>
                <label className="block text-sm font-mono uppercase tracking-wider text-dark-grey mb-2">
                  Art Category *
                </label>
                <select
                  name="art_category"
                  value={formData.art_category}
                  onChange={handleInputChange}
                  required
                  disabled={loading}
                  className="w-full px-4 py-3 border border-grey rounded-lg focus:ring-2 focus:ring-mid-blue focus:border-mid-blue transition-colors disabled:opacity-50"
                >
                  <option value="">Select your category</option>
                  <option value="performing-arts">Performing Arts (Music)</option>
                  <option value="visual-arts">Visual Arts</option>
                  <option value="both">Both</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-mono uppercase tracking-wider text-dark-grey mb-2">
                  Experience Level
                </label>
                <select
                  name="experience"
                  value={formData.experience}
                  onChange={handleInputChange}
                  disabled={loading}
                  className="w-full px-4 py-3 border border-grey rounded-lg focus:ring-2 focus:ring-mid-blue focus:border-mid-blue transition-colors disabled:opacity-50"
                >
                  <option value="">Select experience level</option>
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-mono uppercase tracking-wider text-dark-grey mb-2">
                  Tell us about yourself
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  rows="4"
                  disabled={loading}
                  className="w-full px-4 py-3 border border-grey rounded-lg focus:ring-2 focus:ring-mid-blue focus:border-mid-blue transition-colors resize-none disabled:opacity-50"
                  placeholder="Share your artistic interests and goals..."
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="cta-button bg-black text-white hover:bg-gray-800 w-full disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Submitting...' : 'Submit Application'}
              </button>
            </form>

            <p className="text-xs text-dark-grey mt-4 text-center">
              Visit <a href="http://youthartsforum.org" className="text-mid-blue hover:underline">youthartsforum.org</a> to complete your registration
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default JoinSection;