import React from 'react';
import { Music, Palette } from 'lucide-react';
import { usePrograms } from '../hooks/useApi';
import { LoadingSection } from './LoadingSpinner';
import { ErrorMessage } from './ErrorBoundary';

const ProgramsSection = () => {
  const { data: programs, loading, error, refetch } = usePrograms();

  const iconMap = {
    Music: Music,
    Palette: Palette
  };

  if (loading) {
    return (
      <section id="programs" className="py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <LoadingSection message="Loading programs..." />
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section id="programs" className="py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <ErrorMessage error={error} onRetry={refetch} />
        </div>
      </section>
    );
  }

  return (
    <section id="programs" className="py-24 bg-white">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-6xl font-bold uppercase text-black mb-6">
            Our Programs
          </h2>
          <p className="text-xl text-dark-grey max-w-3xl mx-auto">
            Supporting underfunded music and art programs in schools with supplies and resources
          </p>
        </div>

        {programs && programs.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
            {programs.map((program) => {
              const IconComponent = iconMap[program.icon];
              return (
                <div 
                  key={program.id} 
                  className={`project-card bg-${program.color} p-8 rounded-lg transform hover:scale-105 transition-all duration-300`}
                >
                  <div className="mb-6">
                    {IconComponent && <IconComponent size={48} className="text-black mb-4" />}
                    <h3 className="text-2xl font-bold text-black mb-4">
                      {program.title}
                    </h3>
                    <p className="text-lg text-black/80 leading-relaxed mb-6">
                      {program.description}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-mono text-sm uppercase tracking-wider text-black/60 mb-3">
                      Featured Venues
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {program.venues.slice(0, 4).map((venue, index) => (
                        <span 
                          key={index}
                          className="service-button bg-black/10 text-black text-xs px-3 py-1 rounded-full"
                        >
                          {venue}
                        </span>
                      ))}
                      {program.venues.length > 4 && (
                        <span className="service-button bg-black/10 text-black text-xs px-3 py-1 rounded-full">
                          +{program.venues.length - 4} more
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-xl text-dark-grey">
              Program information will be available soon.
            </p>
          </div>
        )}
      </div>
    </section>
  );
};

export default ProgramsSection;