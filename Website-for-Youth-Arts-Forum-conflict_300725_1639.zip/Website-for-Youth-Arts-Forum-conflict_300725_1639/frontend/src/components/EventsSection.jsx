import React from 'react';
import { Calendar, MapPin, Clock, DollarSign } from 'lucide-react';
import { useEvents } from '../hooks/useApi';
import { LoadingSection } from './LoadingSpinner';
import { ErrorMessage } from './ErrorBoundary';

const EventsSection = () => {
  const { data: featuredEvents, loading, error, refetch } = useEvents({ category: 'performing-arts', limit: 6 });

  if (loading) {
    return (
      <section id="events" className="py-24 bg-light-yellow">
        <div className="container mx-auto px-4 lg:px-8">
          <LoadingSection message="Loading events..." />
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section id="events" className="py-24 bg-light-yellow">
        <div className="container mx-auto px-4 lg:px-8">
          <ErrorMessage error={error} onRetry={refetch} />
        </div>
      </section>
    );
  }

  return (
    <section id="events" className="py-24 bg-light-yellow">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-6xl font-bold uppercase text-black mb-6">
            Featured Events
          </h2>
          <p className="text-xl text-dark-grey max-w-3xl mx-auto">
            Past and upcoming events supporting young artists and school programs
          </p>
        </div>

        {featuredEvents && featuredEvents.length > 0 ? (
          <div className="grid lg:grid-cols-2 gap-12">
            {featuredEvents.slice(0, 2).map((event) => (
              <div key={event.id} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
                {/* Event Flyer */}
                <div className="aspect-square md:aspect-[4/3] overflow-hidden">
                  <img
                    src={event.flyer_url}
                    alt={event.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      e.target.src = 'https://via.placeholder.com/600x400/ff84e4/000000?text=YAF+Event';
                    }}
                  />
                </div>

                {/* Event Details */}
                <div className="p-8">
                  <div className="flex items-center gap-2 mb-4">
                    <span className="service-button bg-mid-purple text-black">
                      {event.category.replace('-', ' ')}
                    </span>
                  </div>

                  <h3 className="text-2xl font-bold text-black mb-4">
                    {event.title}
                  </h3>

                  <p className="text-lg text-dark-grey mb-6 leading-relaxed">
                    {event.description}
                  </p>

                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-3 text-dark-grey">
                      <Calendar size={18} />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-3 text-dark-grey">
                      <Clock size={18} />
                      <span>{event.time}</span>
                    </div>
                    <div className="flex items-center gap-3 text-dark-grey">
                      <MapPin size={18} />
                      <span>{event.venue}, {event.location}</span>
                    </div>
                    <div className="flex items-center gap-3 text-dark-grey">
                      <DollarSign size={18} />
                      <span>{event.price} at the door</span>
                    </div>
                  </div>

                  {/* Featured Artists/Schools */}
                  {event.artists && event.artists.length > 0 && (
                    <div className="mb-6">
                      <h4 className="font-mono text-sm uppercase tracking-wider text-dark-grey mb-3">
                        Featured Artists
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {event.artists.slice(0, 4).map((artist, index) => (
                          <span 
                            key={index}
                            className="service-button bg-light-pink text-black text-xs"
                          >
                            {artist}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {event.schools && event.schools.length > 0 && (
                    <div className="mb-6">
                      <h4 className="font-mono text-sm uppercase tracking-wider text-dark-grey mb-3">
                        Participating Schools
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {event.schools.map((school, index) => (
                          <span 
                            key={index}
                            className="service-button bg-mid-blue text-white text-xs"
                          >
                            {school}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <button className="cta-button bg-black text-white hover:bg-gray-800 w-full">
                    Learn More
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-xl text-dark-grey">
              No events available at the moment. Check back soon for upcoming concerts and exhibitions!
            </p>
          </div>
        )}
      </div>
    </section>
  );
};

export default EventsSection;