import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useHeroSlides } from '../hooks/useApi';
import { LoadingSection } from './LoadingSpinner';
import { ErrorMessage } from './ErrorBoundary';

const HeroSlider = () => {
  const { data: heroSlides, loading, error, refetch } = useHeroSlides();
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    if (!heroSlides || heroSlides.length === 0) return;
    
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [heroSlides]);

  const nextSlide = () => {
    if (!heroSlides) return;
    setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
  };

  const prevSlide = () => {
    if (!heroSlides) return;
    setCurrentSlide((prev) => (prev - 1 + heroSlides.length) % heroSlides.length);
  };

  if (loading) {
    return (
      <section className="h-screen bg-black flex items-center justify-center">
        <LoadingSection message="Loading hero content..." />
      </section>
    );
  }

  if (error) {
    return (
      <section className="h-screen bg-black flex items-center justify-center px-4">
        <ErrorMessage error={error} onRetry={refetch} />
      </section>
    );
  }

  if (!heroSlides || heroSlides.length === 0) {
    return (
      <section className="h-screen bg-black flex items-center justify-center">
        <div className="text-center text-white">
          <h1 className="text-4xl font-bold mb-4">Youth Arts Forum</h1>
          <p className="text-xl">Uniting the Youth of the World Through the Arts</p>
        </div>
      </section>
    );
  }

  const slide = heroSlides[currentSlide];

  return (
    <section className="relative h-screen overflow-hidden">
      {/* Slide Content */}
      <div 
        className="absolute inset-0 transition-all duration-700 ease-in-out"
        style={{ backgroundColor: slide.bg_color, color: slide.text_color }}
      >
        <div className="grid h-full grid-cols-1 md:grid-cols-2">
          {/* Content Side */}
          <div className="flex flex-col justify-between p-6 md:p-12 z-10">
            <div className="pt-20 md:pt-8">
              <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-bold uppercase leading-tight mb-6">
                {slide.title}
              </h1>
              <h2 className="text-xl md:text-2xl font-normal mb-4 opacity-80">
                {slide.subtitle}
              </h2>
              <p className="text-lg md:text-xl font-normal opacity-70 mb-8 max-w-2xl leading-relaxed">
                {slide.description}
              </p>
              <button className="cta-button bg-black text-white hover:bg-gray-800 transition-colors duration-300">
                {slide.cta}
              </button>
            </div>

            {/* Slide Controls */}
            <div className="flex items-center justify-between">
              <div className="flex space-x-2">
                {heroSlides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-all ${
                      index === currentSlide ? 'bg-current' : 'bg-current opacity-30'
                    }`}
                  />
                ))}
              </div>
              
              <div className="flex space-x-4">
                <button
                  onClick={prevSlide}
                  className="w-10 h-10 rounded-full bg-current/20 flex items-center justify-center hover:bg-current/30 transition-colors"
                >
                  <ChevronLeft size={20} />
                </button>
                <button
                  onClick={nextSlide}
                  className="w-10 h-10 rounded-full bg-current/20 flex items-center justify-center hover:bg-current/30 transition-colors"
                >
                  <ChevronRight size={20} />
                </button>
              </div>
            </div>
          </div>

          {/* Image Side */}
          <div className="relative">
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover"
              onError={(e) => {
                e.target.src = 'https://via.placeholder.com/800x600/1f47e6/ffffff?text=Youth+Arts+Forum';
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-l from-transparent via-transparent to-black/20" />
          </div>
        </div>

        {/* Brand Text Overlay */}
        <div className="absolute bottom-6 left-6 md:bottom-12 md:left-12 z-20">
          <h3 className="font-display text-6xl md:text-8xl lg:text-9xl font-black uppercase leading-none opacity-20">
            YAF
          </h3>
        </div>
      </div>
    </section>
  );
};

export default HeroSlider;