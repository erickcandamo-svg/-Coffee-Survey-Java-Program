# Youth Arts Forum - API Contracts

## Overview
This document outlines the API endpoints and data contracts needed to replace mock data with real backend functionality for the Youth Arts Forum website.

## Current Mock Data (frontend/src/data/mock.js)

### 1. Hero Slides
- **Mock Data**: 3 slides with YAF messaging and user-provided images
- **Backend Need**: Dynamic content management for hero slides
- **API**: `GET /api/slides` - Returns array of slide objects

### 2. Featured Events  
- **Mock Data**: 2 events with concert flyers, dates, venues, artists
- **Backend Need**: Event management system
- **API**: `GET /api/events` - Returns upcoming events with pagination

### 3. Member Showcase
- **Mock Data**: 3 member profiles with images and categories
- **Backend Need**: Member gallery and profile system
- **API**: `GET /api/members` - Returns featured members

### 4. Programs
- **Mock Data**: Performing Arts and Visual Arts program info
- **Backend Need**: Program content management
- **API**: `GET /api/programs` - Returns program details

### 5. Contact Info & Social Links
- **Mock Data**: Static contact information and social media links
- **Backend Need**: Settings management
- **API**: `GET /api/settings` - Returns site configuration

## Required API Endpoints

### Events Management
```
GET /api/events
- Returns: Array of event objects
- Pagination: ?page=1&limit=10
- Filter: ?category=performing-arts|visual-arts

POST /api/events (Admin)
- Create new event
- Body: { title, date, venue, description, flyer_url, artists[], category }

PUT /api/events/:id (Admin)
- Update event details
```

### Members Management  
```
GET /api/members
- Returns: Array of member profiles
- Filter: ?category=performing-arts|visual-arts|both

POST /api/members
- Member registration/application
- Body: { name, email, age, art_category, experience, message }

GET /api/members/:id
- Get individual member profile
```

### Contact Forms
```
POST /api/contact
- General inquiries
- Body: { name, email, subject, message }

POST /api/join
- Membership applications  
- Body: { name, email, age, art_category, experience, message }
```

### Content Management
```
GET /api/slides
- Hero slider content

GET /api/programs  
- Programs information

GET /api/settings
- Site configuration (contact info, social links, donation link)
```

## Database Models

### Event
```javascript
{
  _id: ObjectId,
  title: String,
  date: Date,
  time: String, 
  venue: String,
  location: String,
  price: String,
  description: String,
  flyer_url: String,
  artists: [String],
  schools: [String], 
  category: String, // 'performing-arts' | 'visual-arts'
  created_at: Date,
  updated_at: Date
}
```

### Member
```javascript
{
  _id: ObjectId,
  name: String,
  email: String,
  age: Number,
  art_category: String, // 'performing-arts' | 'visual-arts' | 'both'
  experience: String, // 'beginner' | 'intermediate' | 'advanced'
  message: String,
  image_url: String,
  featured: Boolean,
  status: String, // 'pending' | 'approved' | 'active'
  created_at: Date
}
```

### ContactForm
```javascript
{
  _id: ObjectId,
  name: String,
  email: String,
  subject: String,
  message: String,
  type: String, // 'contact' | 'join'
  status: String, // 'new' | 'read' | 'responded'
  created_at: Date
}
```

## Frontend Integration Plan

1. **Replace mock imports**: Remove mock.js imports and replace with API calls
2. **Add API service layer**: Create services/api.js for all backend calls  
3. **Add loading states**: Implement loading spinners for async data
4. **Error handling**: Add error boundaries and user feedback
5. **Form submissions**: Connect join form and contact forms to backend

## Key Features to Implement

1. **Event Management**: CRUD operations for events/concerts
2. **Member Applications**: Handle join form submissions 
3. **Contact Forms**: General inquiries and membership applications
4. **Image Upload**: For member photos and event flyers (if needed)
5. **Admin Panel**: Basic admin interface for content management

## Environment Variables Needed

- `MONGO_URL`: Already configured
- `EMAIL_SERVICE`: For contact form notifications (optional)
- `ADMIN_SECRET`: For admin authentication (optional)

## Testing Strategy

1. Test all API endpoints with sample data
2. Verify frontend-backend integration
3. Test form submissions and validations
4. Ensure responsive design works with real data
5. Test image loading and error handling