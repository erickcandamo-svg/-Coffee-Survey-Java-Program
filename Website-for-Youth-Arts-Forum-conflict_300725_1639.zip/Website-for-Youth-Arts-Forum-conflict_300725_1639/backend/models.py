from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import datetime
import uuid
from enum import Enum

# Enums for validation
class ArtCategory(str, Enum):
    PERFORMING_ARTS = "performing-arts"
    VISUAL_ARTS = "visual-arts"
    BOTH = "both"

class ExperienceLevel(str, Enum):
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"

class MemberStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    ACTIVE = "active"

class ContactStatus(str, Enum):
    NEW = "new"
    READ = "read"
    RESPONDED = "responded"

class ContactType(str, Enum):
    CONTACT = "contact"
    JOIN = "join"

# Database Models
class Event(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    date: str  # We'll store as string for flexibility
    time: str
    venue: str
    location: str
    price: str
    description: str
    flyer_url: str
    artists: List[str] = []
    schools: List[str] = []
    category: ArtCategory
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class EventCreate(BaseModel):
    title: str
    date: str
    time: str
    venue: str
    location: str
    price: str
    description: str
    flyer_url: str
    artists: List[str] = []
    schools: List[str] = []
    category: ArtCategory

class Member(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: EmailStr
    age: int = Field(ge=1, le=25)
    art_category: ArtCategory
    experience: Optional[ExperienceLevel] = None
    message: Optional[str] = None
    image_url: Optional[str] = None
    featured: bool = False
    status: MemberStatus = MemberStatus.PENDING
    created_at: datetime = Field(default_factory=datetime.utcnow)

class MemberCreate(BaseModel):
    name: str
    email: EmailStr
    age: int = Field(ge=1, le=25)
    art_category: ArtCategory
    experience: Optional[ExperienceLevel] = None
    message: Optional[str] = None

class ContactForm(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: EmailStr
    subject: Optional[str] = None
    message: str
    type: ContactType
    status: ContactStatus = ContactStatus.NEW
    created_at: datetime = Field(default_factory=datetime.utcnow)

class ContactCreate(BaseModel):
    name: str
    email: EmailStr
    subject: Optional[str] = None
    message: str

class JoinCreate(BaseModel):
    name: str
    email: EmailStr
    age: int = Field(ge=1, le=25)
    art_category: ArtCategory
    experience: Optional[ExperienceLevel] = None
    message: Optional[str] = None

class HeroSlide(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    subtitle: str
    description: str
    bg_color: str
    text_color: str
    cta: str
    image: str
    order: int = 0
    active: bool = True

class Program(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    description: str
    venues: List[str]
    color: str
    icon: str

class SiteSettings(BaseModel):
    founder: str = "Barry Salottolo"
    website: str = "http://youthartsforum.org"
    email: str = "info@youthartsforum.org"
    address: str = "106 William Street, Norwalk, CT 06851"
    phone: str = "(914) 310-2930"
    donation_link: str = "https://www.paypal.com/donate/?hosted_button_id=44ZH6XWEQHMW8"
    social_links: List[dict] = [
        {"name": "Instagram", "url": "https://www.instagram.com/youthartsforum/", "icon": "Instagram"},
        {"name": "Facebook", "url": "https://www.facebook.com/youthartsforum.org/", "icon": "Facebook"},
        {"name": "YouTube", "url": "https://www.youtube.com/@barrysalottolo3548", "icon": "Youtube"}
    ]
    stats: List[dict] = [
        {"number": "30+", "label": "Years Supporting Youth"},
        {"number": "32", "label": "Simon Mall Venues"},
        {"number": "1000+", "label": "Young Artists Supported"},
        {"number": "501(c)(3)", "label": "Registered Charity"}
    ]