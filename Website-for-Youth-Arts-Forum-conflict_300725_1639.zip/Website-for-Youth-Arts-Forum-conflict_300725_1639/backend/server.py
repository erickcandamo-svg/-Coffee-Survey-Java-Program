from fastapi import FastAPI, APIRouter, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
from pathlib import Path
import os
import logging
from typing import List, Optional
from datetime import datetime

# Import models
from models import (
    Event, EventCreate, Member, MemberCreate, ContactForm, ContactCreate, 
    JoinCreate, HeroSlide, Program, SiteSettings, ArtCategory, MemberStatus
)

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app
app = FastAPI(title="Youth Arts Forum API", version="1.0.0")

# Create API router
api_router = APIRouter(prefix="/api")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize sample data
async def init_sample_data():
    """Initialize the database with sample data on startup"""
    try:
        # Check if data already exists
        events_count = await db.events.count_documents({})
        if events_count > 0:
            return
        
        # Sample Events
        sample_events = [
            {
                "id": "1",
                "title": "The Bitter End NYC",
                "date": "October 5th, 2024",
                "time": "1:00 PM",
                "venue": "The Bitter End",
                "location": "NYC",
                "price": "$10.00",
                "description": "Chillin to some amazing music in the Fall",
                "artists": ["Double A", "SOR Farmingdale", "Sor Sayville", "Adolescence", "Glenn Strange", "Fallen Anthem"],
                "flyer_url": "https://customer-assets.emergentagent.com/job_artsforum/artifacts/4qa5rey7_Music-flyer105.png",
                "category": "performing-arts",
                "schools": [],
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow()
            },
            {
                "id": "2", 
                "title": "Battle of the School of Rock",
                "date": "March 25th, 2023",
                "time": "1:00 PM - 5:30 PM",
                "venue": "The Iconic Bitter End",
                "location": "NYC",
                "price": "$10.00",
                "description": "Concert to benefit art & music in underfunded schools",
                "schools": ["SOR Ridgefield CT", "SOR New Canaan CT", "SOR Montclair NJ"],
                "flyer_url": "https://customer-assets.emergentagent.com/job_artsforum/artifacts/uh59zws6_march%2025th%20bitter%20end.png",
                "category": "performing-arts",
                "artists": [],
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow()
            }
        ]
        
        # Sample Hero Slides
        sample_slides = [
            {
                "id": "1",
                "title": "Uniting the Youth of the World Through the Arts",
                "subtitle": "Empowering young artists and performers worldwide since 1990",
                "description": "Youth Arts Forum provides art and music supplies and support for underfunded music and art programs in schools.",
                "bg_color": "#1f47e6",
                "text_color": "#b7fbff",
                "cta": "Join Our Community",
                "image": "https://customer-assets.emergentagent.com/job_artsforum/artifacts/wynpsnwg_sor%20ridgefield.jpeg",
                "order": 1,
                "active": True
            },
            {
                "id": "2",
                "title": "Supporting Schools",
                "subtitle": "Art & Music Program Support",
                "description": "We provide essential supplies and support for underfunded art and music programs across schools nationwide.",
                "bg_color": "#d987ff",
                "text_color": "#151515",
                "cta": "Learn More",
                "image": "https://customer-assets.emergentagent.com/job_artsforum/artifacts/e77n5vxe_dial%20tone.jpeg",
                "order": 2,
                "active": True
            },
            {
                "id": "3",
                "title": "Visual Arts Program",
                "subtitle": "Gallery Exhibitions & Art Supplies",
                "description": "Showcasing young talent in renowned spaces while distributing art supplies to those in need.",
                "bg_color": "#ff84e4",
                "text_color": "#151515",
                "cta": "Explore Gallery",
                "image": "https://customer-assets.emergentagent.com/job_artsforum/artifacts/vuiqtxhf_double%20a.jpeg",
                "order": 3,
                "active": True
            }
        ]
        
        # Sample Members
        sample_members = [
            {
                "id": "1",
                "name": "YAF Rock Band Members",
                "email": "rockband@yaf.org",
                "age": 16,
                "art_category": "performing-arts",
                "experience": "intermediate",
                "message": "Young musicians showcasing their talent at YAF events",
                "image_url": "https://customer-assets.emergentagent.com/job_artsforum/artifacts/e77n5vxe_dial%20tone.jpeg",
                "featured": True,
                "status": "active",
                "created_at": datetime.utcnow()
            },
            {
                "id": "2",
                "name": "YAF Community",
                "email": "community@yaf.org", 
                "age": 17,
                "art_category": "both",
                "experience": "advanced",
                "message": "Our diverse community of young artists and performers",
                "image_url": "https://customer-assets.emergentagent.com/job_artsforum/artifacts/wynpsnwg_sor%20ridgefield.jpeg",
                "featured": True,
                "status": "active",
                "created_at": datetime.utcnow()
            },
            {
                "id": "3",
                "name": "Double A",
                "email": "doublea@yaf.org",
                "age": 18,
                "art_category": "visual-arts",
                "experience": "advanced", 
                "message": "Emerging artist showcasing creative visual expression",
                "image_url": "https://customer-assets.emergentagent.com/job_artsforum/artifacts/vuiqtxhf_double%20a.jpeg",
                "featured": True,
                "status": "active",
                "created_at": datetime.utcnow()
            }
        ]
        
        # Sample Programs
        sample_programs = [
            {
                "id": "1",
                "title": "Performing Arts",
                "description": "Supporting music programs in schools with instrument donations, equipment, and performance opportunities. We help underfunded schools maintain their music education programs.",
                "venues": ["Schools Nationwide", "Community Centers", "The Bitter End (Past Events)", "Various Performance Venues"],
                "color": "mid-blue",
                "icon": "Music"
            },
            {
                "id": "2",
                "title": "Visual Arts",
                "description": "Art supply distribution and professional framing for underfunded school art programs. We also organize gallery exhibitions to showcase young talent.",
                "venues": ["NOHO Art Gallery", "Rivington Street Gallery", "Parasol Project", "School Art Programs"],
                "color": "mid-purple",
                "icon": "Palette"
            }
        ]
        
        # Insert sample data
        await db.events.insert_many(sample_events)
        await db.hero_slides.insert_many(sample_slides) 
        await db.members.insert_many(sample_members)
        await db.programs.insert_many(sample_programs)
        
        logger.info("Sample data initialized successfully")
        
    except Exception as e:
        logger.error(f"Error initializing sample data: {e}")

# Events endpoints
@api_router.get("/events", response_model=List[Event])
async def get_events(
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=100),
    category: Optional[ArtCategory] = None
):
    """Get events with pagination and optional category filter"""
    skip = (page - 1) * limit
    query = {}
    if category:
        query["category"] = category.value
    
    events = await db.events.find(query).sort("created_at", -1).skip(skip).limit(limit).to_list(length=limit)
    return [Event(**event) for event in events]

@api_router.post("/events", response_model=Event)
async def create_event(event: EventCreate):
    """Create a new event"""
    event_dict = event.dict()
    event_obj = Event(**event_dict)
    await db.events.insert_one(event_obj.dict())
    return event_obj

@api_router.get("/events/{event_id}", response_model=Event)
async def get_event(event_id: str):
    """Get a specific event by ID"""
    event = await db.events.find_one({"id": event_id})
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    return Event(**event)

# Members endpoints
@api_router.get("/members", response_model=List[Member])
async def get_members(
    category: Optional[ArtCategory] = None,
    featured: Optional[bool] = None,
    limit: int = Query(20, ge=1, le=100)
):
    """Get members with optional filters"""
    query = {}
    if category:
        query["art_category"] = category.value
    if featured is not None:
        query["featured"] = featured
    
    members = await db.members.find(query).sort("created_at", -1).limit(limit).to_list(length=limit)
    return [Member(**member) for member in members]

@api_router.post("/members", response_model=Member)
async def create_member_application(member_data: JoinCreate):
    """Create a new member application"""
    member_dict = member_data.dict()
    member_obj = Member(**member_dict)
    await db.members.insert_one(member_obj.dict())
    return member_obj

@api_router.get("/members/{member_id}", response_model=Member)
async def get_member(member_id: str):
    """Get a specific member by ID"""
    member = await db.members.find_one({"id": member_id})
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")
    return Member(**member)

# Contact form endpoints
@api_router.post("/contact", response_model=ContactForm)
async def submit_contact_form(contact_data: ContactCreate):
    """Submit a contact form"""
    contact_dict = contact_data.dict()
    contact_dict["type"] = "contact"
    contact_obj = ContactForm(**contact_dict)
    await db.contact_forms.insert_one(contact_obj.dict())
    return contact_obj

@api_router.post("/join", response_model=Member)
async def submit_join_form(join_data: JoinCreate):
    """Submit a join application"""
    # Create member record
    member_dict = join_data.dict()
    member_obj = Member(**member_dict)
    await db.members.insert_one(member_obj.dict())
    
    # Also create a contact form record for tracking
    contact_dict = {
        "name": join_data.name,
        "email": join_data.email,
        "subject": f"Membership Application - {join_data.art_category}",
        "message": join_data.message or f"Application for {join_data.art_category}",
        "type": "join"
    }
    contact_obj = ContactForm(**contact_dict)
    await db.contact_forms.insert_one(contact_obj.dict())
    
    return member_obj

# Content endpoints
@api_router.get("/slides", response_model=List[HeroSlide])
async def get_hero_slides():
    """Get hero slides"""
    slides = await db.hero_slides.find({"active": True}).sort("order", 1).to_list(length=10)
    return [HeroSlide(**slide) for slide in slides]

@api_router.get("/programs", response_model=List[Program])
async def get_programs():
    """Get programs"""
    programs = await db.programs.find({}).to_list(length=10)
    return [Program(**program) for program in programs]

@api_router.get("/settings", response_model=SiteSettings)
async def get_site_settings():
    """Get site settings"""
    return SiteSettings()

# Health check
@api_router.get("/")
async def root():
    return {"message": "Youth Arts Forum API", "status": "healthy"}

# Include the router in the main app
app.include_router(api_router)

@app.on_event("startup")
async def startup_event():
    """Initialize sample data on startup"""
    await init_sample_data()

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()