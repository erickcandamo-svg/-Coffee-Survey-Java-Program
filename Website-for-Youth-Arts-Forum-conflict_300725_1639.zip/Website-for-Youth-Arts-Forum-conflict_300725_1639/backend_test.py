#!/usr/bin/env python3
"""
Comprehensive Backend API Testing for Youth Arts Forum
Tests all API endpoints with proper validation and error handling
"""

import requests
import json
import sys
from datetime import datetime
from typing import Dict, Any, List

# Get backend URL from frontend .env file
def get_backend_url():
    try:
        with open('/app/frontend/.env', 'r') as f:
            for line in f:
                if line.startswith('REACT_APP_BACKEND_URL='):
                    return line.split('=', 1)[1].strip()
    except Exception as e:
        print(f"Error reading frontend .env: {e}")
        return None

BASE_URL = get_backend_url()
if not BASE_URL:
    print("❌ Could not get backend URL from frontend/.env")
    sys.exit(1)

API_BASE = f"{BASE_URL}/api"
print(f"🔗 Testing API at: {API_BASE}")

class APITester:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
        self.results = {
            'passed': 0,
            'failed': 0,
            'errors': []
        }

    def test_endpoint(self, method: str, endpoint: str, data: Dict = None, 
                     expected_status: int = 200, description: str = ""):
        """Test a single API endpoint"""
        url = f"{API_BASE}{endpoint}"
        
        try:
            if method.upper() == 'GET':
                response = self.session.get(url)
            elif method.upper() == 'POST':
                response = self.session.post(url, json=data)
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            # Check status code
            if response.status_code == expected_status:
                print(f"✅ {method} {endpoint} - {description}")
                self.results['passed'] += 1
                
                # Try to parse JSON response
                try:
                    json_data = response.json()
                    return True, json_data
                except json.JSONDecodeError:
                    print(f"⚠️  Response is not valid JSON")
                    return True, response.text
                    
            else:
                error_msg = f"Expected status {expected_status}, got {response.status_code}"
                print(f"❌ {method} {endpoint} - {description}: {error_msg}")
                print(f"   Response: {response.text[:200]}")
                self.results['failed'] += 1
                self.results['errors'].append(f"{method} {endpoint}: {error_msg}")
                return False, None
                
        except requests.exceptions.RequestException as e:
            error_msg = f"Request failed: {str(e)}"
            print(f"❌ {method} {endpoint} - {description}: {error_msg}")
            self.results['failed'] += 1
            self.results['errors'].append(f"{method} {endpoint}: {error_msg}")
            return False, None

    def test_health_check(self):
        """Test basic health check endpoint"""
        print("\n🏥 Testing Health Check...")
        success, data = self.test_endpoint('GET', '/', description="Health check")
        if success and isinstance(data, dict):
            if data.get('message') == 'Youth Arts Forum API' and data.get('status') == 'healthy':
                print("   ✅ Health check response is correct")
            else:
                print(f"   ⚠️  Unexpected health check response: {data}")

    def test_events_api(self):
        """Test Events API endpoints"""
        print("\n🎭 Testing Events API...")
        
        # Test GET /api/events (basic)
        success, events = self.test_endpoint('GET', '/events', description="Get all events")
        if success and isinstance(events, list):
            print(f"   ✅ Retrieved {len(events)} events")
            
            # Validate event structure
            if events:
                event = events[0]
                required_fields = ['id', 'title', 'date', 'venue', 'location', 'price', 'description', 'flyer_url', 'category']
                missing_fields = [field for field in required_fields if field not in event]
                if missing_fields:
                    print(f"   ⚠️  Event missing fields: {missing_fields}")
                else:
                    print("   ✅ Event structure is valid")
                    
                # Check for YAF concert flyers
                yaf_events = [e for e in events if 'Bitter End' in e.get('title', '') or 'Battle of the School' in e.get('title', '')]
                if yaf_events:
                    print(f"   ✅ Found {len(yaf_events)} YAF concert events")
                else:
                    print("   ⚠️  No YAF concert events found")
        
        # Test GET /api/events with pagination
        success, paginated = self.test_endpoint('GET', '/events?page=1&limit=5', description="Get events with pagination")
        if success and isinstance(paginated, list):
            print(f"   ✅ Pagination working - got {len(paginated)} events (limit=5)")
        
        # Test GET /api/events with category filter
        success, filtered = self.test_endpoint('GET', '/events?category=performing-arts', description="Filter events by category")
        if success and isinstance(filtered, list):
            print(f"   ✅ Category filtering working - got {len(filtered)} performing-arts events")
        
        # Test GET /api/events/{id} with valid ID
        if success and events and len(events) > 0:
            event_id = events[0]['id']
            success, single_event = self.test_endpoint('GET', f'/events/{event_id}', description=f"Get event by ID ({event_id})")
            if success and isinstance(single_event, dict):
                if single_event.get('id') == event_id:
                    print("   ✅ Single event retrieval working")
                else:
                    print("   ⚠️  Retrieved event ID doesn't match requested ID")
        
        # Test GET /api/events/{id} with invalid ID
        self.test_endpoint('GET', '/events/invalid-id', expected_status=404, description="Get event with invalid ID")
        
        # Test POST /api/events (create new event)
        new_event_data = {
            "title": "Test Concert Event",
            "date": "December 15th, 2024",
            "time": "7:00 PM",
            "venue": "Test Venue",
            "location": "Test City",
            "price": "$15.00",
            "description": "Test event for API validation",
            "flyer_url": "https://example.com/test-flyer.jpg",
            "artists": ["Test Artist 1", "Test Artist 2"],
            "schools": ["Test School"],
            "category": "performing-arts"
        }
        
        success, created_event = self.test_endpoint('POST', '/events', data=new_event_data, 
                                                   expected_status=200, description="Create new event")
        if success and isinstance(created_event, dict):
            if created_event.get('title') == new_event_data['title']:
                print("   ✅ Event creation working correctly")
            else:
                print("   ⚠️  Created event data doesn't match input")

    def test_members_api(self):
        """Test Members API endpoints"""
        print("\n👥 Testing Members API...")
        
        # Test GET /api/members (basic)
        success, members = self.test_endpoint('GET', '/members', description="Get all members")
        if success and isinstance(members, list):
            print(f"   ✅ Retrieved {len(members)} members")
            
            # Validate member structure
            if members:
                member = members[0]
                required_fields = ['id', 'name', 'email', 'age', 'art_category', 'status']
                missing_fields = [field for field in required_fields if field not in member]
                if missing_fields:
                    print(f"   ⚠️  Member missing fields: {missing_fields}")
                else:
                    print("   ✅ Member structure is valid")
                    
                # Check for sample artists with photos
                members_with_photos = [m for m in members if m.get('image_url')]
                if members_with_photos:
                    print(f"   ✅ Found {len(members_with_photos)} members with photos")
                else:
                    print("   ⚠️  No members with photos found")
        
        # Test GET /api/members with category filter
        success, filtered = self.test_endpoint('GET', '/members?category=performing-arts', description="Filter members by category")
        if success and isinstance(filtered, list):
            print(f"   ✅ Category filtering working - got {len(filtered)} performing-arts members")
        
        # Test GET /api/members with featured filter
        success, featured = self.test_endpoint('GET', '/members?featured=true', description="Filter featured members")
        if success and isinstance(featured, list):
            print(f"   ✅ Featured filtering working - got {len(featured)} featured members")
        
        # Test POST /api/join (member application)
        join_data = {
            "name": "Alex Johnson",
            "email": "alex.johnson@example.com",
            "age": 17,
            "art_category": "both",
            "experience": "intermediate",
            "message": "I'm passionate about both visual and performing arts and would love to join YAF!"
        }
        
        success, new_member = self.test_endpoint('POST', '/join', data=join_data, 
                                               expected_status=200, description="Submit join application")
        if success and isinstance(new_member, dict):
            if new_member.get('name') == join_data['name'] and new_member.get('email') == join_data['email']:
                print("   ✅ Join application working correctly")
            else:
                print("   ⚠️  Join application data doesn't match input")

    def test_hero_slides_api(self):
        """Test Hero Slides API"""
        print("\n🎨 Testing Hero Slides API...")
        
        success, slides = self.test_endpoint('GET', '/slides', description="Get hero slides")
        if success and isinstance(slides, list):
            print(f"   ✅ Retrieved {len(slides)} hero slides")
            
            # Validate slide structure
            if slides:
                slide = slides[0]
                required_fields = ['id', 'title', 'subtitle', 'description', 'bg_color', 'text_color', 'cta', 'image']
                missing_fields = [field for field in required_fields if field not in slide]
                if missing_fields:
                    print(f"   ⚠️  Slide missing fields: {missing_fields}")
                else:
                    print("   ✅ Slide structure is valid")
                
                # Check for updated messaging
                yaf_messaging = any('Uniting the Youth of the World Through the Arts' in slide.get('title', '') or 
                                  'Uniting the Youth of the World Through the Arts' in slide.get('subtitle', '') or
                                  'Uniting the Youth of the World Through the Arts' in slide.get('description', '') 
                                  for slide in slides)
                if yaf_messaging:
                    print("   ✅ Found updated YAF messaging in slides")
                else:
                    print("   ⚠️  Updated YAF messaging not found in slides")

    def test_contact_forms_api(self):
        """Test Contact Forms API"""
        print("\n📧 Testing Contact Forms API...")
        
        # Test POST /api/contact
        contact_data = {
            "name": "Sarah Wilson",
            "email": "sarah.wilson@example.com",
            "subject": "Question about programs",
            "message": "I'd like to learn more about your visual arts programs for schools."
        }
        
        success, contact_response = self.test_endpoint('POST', '/contact', data=contact_data,
                                                     expected_status=200, description="Submit contact form")
        if success and isinstance(contact_response, dict):
            if (contact_response.get('name') == contact_data['name'] and 
                contact_response.get('email') == contact_data['email']):
                print("   ✅ Contact form submission working correctly")
            else:
                print("   ⚠️  Contact form response doesn't match input")

    def test_settings_api(self):
        """Test Settings and Programs API"""
        print("\n⚙️  Testing Settings API...")
        
        # Test GET /api/settings
        success, settings = self.test_endpoint('GET', '/settings', description="Get site settings")
        if success and isinstance(settings, dict):
            required_fields = ['founder', 'website', 'email', 'address', 'phone', 'donation_link']
            missing_fields = [field for field in required_fields if field not in settings]
            if missing_fields:
                print(f"   ⚠️  Settings missing fields: {missing_fields}")
            else:
                print("   ✅ Settings structure is valid")
                
                # Check for YAF-specific data
                if settings.get('founder') == 'Barry Salottolo':
                    print("   ✅ Correct founder information")
                if 'youthartsforum.org' in settings.get('website', ''):
                    print("   ✅ Correct website information")
        
        # Test GET /api/programs
        success, programs = self.test_endpoint('GET', '/programs', description="Get programs")
        if success and isinstance(programs, list):
            print(f"   ✅ Retrieved {len(programs)} programs")
            
            if programs:
                program = programs[0]
                required_fields = ['id', 'title', 'description', 'venues']
                missing_fields = [field for field in required_fields if field not in program]
                if missing_fields:
                    print(f"   ⚠️  Program missing fields: {missing_fields}")
                else:
                    print("   ✅ Program structure is valid")
                    
                # Check for school program support content
                school_support = any('school' in program.get('description', '').lower() or 
                                   'underfunded' in program.get('description', '').lower()
                                   for program in programs)
                if school_support:
                    print("   ✅ Found school program support content")
                else:
                    print("   ⚠️  School program support content not found")

    def test_data_persistence(self):
        """Test that data persists correctly"""
        print("\n💾 Testing Data Persistence...")
        
        # Create a test member and verify it persists
        test_member_data = {
            "name": "Data Persistence Test",
            "email": "persistence@test.com",
            "age": 19,
            "art_category": "visual-arts",
            "experience": "beginner",
            "message": "Testing data persistence"
        }
        
        # Submit join application
        success, created_member = self.test_endpoint('POST', '/join', data=test_member_data,
                                                   description="Create test member for persistence")
        
        if success and created_member:
            member_id = created_member.get('id')
            if member_id:
                # Try to retrieve the created member
                success, retrieved_member = self.test_endpoint('GET', f'/members/{member_id}',
                                                             description="Retrieve created member")
                if success and retrieved_member:
                    if (retrieved_member.get('name') == test_member_data['name'] and
                        retrieved_member.get('email') == test_member_data['email']):
                        print("   ✅ Data persistence working correctly")
                    else:
                        print("   ⚠️  Retrieved data doesn't match created data")
                else:
                    print("   ❌ Could not retrieve created member")
            else:
                print("   ⚠️  Created member has no ID")

    def test_error_handling(self):
        """Test API error handling"""
        print("\n🚨 Testing Error Handling...")
        
        # Test invalid JSON data
        try:
            response = self.session.post(f"{API_BASE}/contact", data="invalid json")
            if response.status_code in [400, 422]:
                print("   ✅ Invalid JSON properly rejected")
                self.results['passed'] += 1
            else:
                print(f"   ⚠️  Invalid JSON got status {response.status_code}")
                self.results['failed'] += 1
        except Exception as e:
            print(f"   ❌ Error testing invalid JSON: {e}")
            self.results['failed'] += 1
        
        # Test missing required fields
        incomplete_contact = {"name": "Test"}  # Missing required fields
        success, _ = self.test_endpoint('POST', '/contact', data=incomplete_contact,
                                      expected_status=422, description="Submit incomplete contact form")
        
        # Test invalid email format
        invalid_email_data = {
            "name": "Test User",
            "email": "invalid-email",
            "age": 18,
            "art_category": "visual-arts"
        }
        success, _ = self.test_endpoint('POST', '/join', data=invalid_email_data,
                                      expected_status=422, description="Submit join with invalid email")

    def run_all_tests(self):
        """Run all API tests"""
        print("🚀 Starting Comprehensive Backend API Testing for Youth Arts Forum")
        print("=" * 70)
        
        self.test_health_check()
        self.test_events_api()
        self.test_members_api()
        self.test_hero_slides_api()
        self.test_contact_forms_api()
        self.test_settings_api()
        self.test_data_persistence()
        self.test_error_handling()
        
        print("\n" + "=" * 70)
        print("📊 TEST RESULTS SUMMARY")
        print("=" * 70)
        print(f"✅ Passed: {self.results['passed']}")
        print(f"❌ Failed: {self.results['failed']}")
        print(f"📈 Success Rate: {(self.results['passed'] / (self.results['passed'] + self.results['failed']) * 100):.1f}%")
        
        if self.results['errors']:
            print("\n🚨 ERRORS ENCOUNTERED:")
            for error in self.results['errors']:
                print(f"   • {error}")
        
        return self.results['failed'] == 0

if __name__ == "__main__":
    tester = APITester()
    success = tester.run_all_tests()
    
    if success:
        print("\n🎉 All tests passed! Backend API is working correctly.")
        sys.exit(0)
    else:
        print(f"\n⚠️  Some tests failed. Check the errors above.")
        sys.exit(1)